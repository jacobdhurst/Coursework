#include "ll.h"
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

int insert_count, access_count;

void *inserting(void *args)
{
    ll_t* list = (ll_t*) args;
    while(1)
    {
        
        ll_insert_last(list, (void *)&insert_count);
        insert_count++;
    }
}

void *accessing(void *args)
{
    ll_t* list = (ll_t*) args;
    while(1)
    {
        ll_get_n(list, insert_count);
        access_count++;
    }
}
static void alarm_handle(int sig)
{
    printf("Thread-safe insert count: %d.\n", insert_count);
    printf("Thread-safe access count: %d.\n", access_count);
    exit(0);
}

int main(int argc, char *argv[]) 
{
    signal(SIGALRM, alarm_handle);
    alarm(2*atoi(argv[1]));

    ll_t* list = ll_new(NULL);

    pthread_t thread1, thread2;

    pthread_create(&thread1, NULL, inserting, (void*)list);
    pthread_create(&thread2, NULL, accessing, (void*)list);

    sleep(60);
    exit(0);
}